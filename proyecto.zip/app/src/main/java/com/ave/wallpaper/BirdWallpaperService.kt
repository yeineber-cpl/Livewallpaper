package com.ave.wallpaper

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class BirdWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = BirdEngine()

    inner class BirdEngine : Engine() {

        // ── Ajustes (en dp) ──
        private val density = this@BirdWallpaperService.resources.displayMetrics.density
        private val size = 12f * density       // tamaño del ave
        private val speed = 38f * density      // velocidad
        private val turn = 1.1f                // giro máximo en rad/s
        private val glideRate = 0.15f          // frecuencia de planeo
        private val margin = 0.08f             // cuánto se puede salir de la pantalla
        private val frameMs = 33L              // ~30 fps

        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2A2A2A")
            alpha = 230
        }
        private val path = Path()
        private val oval = RectF()
        private val pi = PI.toFloat()

        private var w = 0f
        private var h = 0f
        private var placed = false
        private var visible = false
        private var x = 0f
        private var y = 0f
        private var a = Random.nextFloat() * 2f * PI.toFloat()
        private var phase = 0f
        private var glide = 0f
        private var tx = 0f
        private var ty = 0f
        private var last = 0L

        private val frame = object : Runnable {
            override fun run() {
                step()
                drawFrame()
                if (visible) handler.postDelayed(this, frameMs)
            }
        }

        private fun rnd(lo: Float, hi: Float): Float = lo + Random.nextFloat() * (hi - lo)

        private fun newTarget() {
            tx = rnd(-w * margin, w * (1f + margin))
            ty = rnd(-h * margin, h * (1f + margin))
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width.toFloat()
            h = height.toFloat()
            if (!placed) {
                x = w / 2f
                y = h / 2f
                newTarget()
                placed = true
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(frame)
            if (isVisible) {
                last = System.nanoTime()
                handler.post(frame)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(frame)
            super.onDestroy()
        }

        private fun step() {
            if (!placed) return
            val now = System.nanoTime()
            val dt = min((now - last) / 1_000_000_000f, 0.1f)
            last = now

            val dx = tx - x
            val dy = ty - y
            if (hypot(dx, dy) < 50f * density) newTarget()

            var d = atan2(dy, dx) - a
            while (d > pi) d -= 2f * pi
            while (d < -pi) d += 2f * pi
            val maxT = turn * dt
            a += d.coerceIn(-maxT, maxT)

            x += cos(a) * speed * dt
            y += sin(a) * speed * dt

            if (glide > 0f) glide -= dt
            else if (Random.nextFloat() < dt * glideRate) glide = rnd(0.8f, 2f)
            phase += dt * 14f
        }

        private fun drawFrame() {
            if (!placed) return
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) draw(canvas)
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun draw(c: Canvas) {
            c.drawColor(Color.WHITE)

            val s = size
            val spread = if (glide > 0f) 1f else 0.5f + 0.5f * abs(sin(phase))

            c.save()
            c.translate(x, y)
            c.rotate(Math.toDegrees(a.toDouble()).toFloat())

            // alas curvas
            for (side in floatArrayOf(-1f, 1f)) {
                val wv = side * spread
                path.reset()
                path.moveTo(s * 0.22f, side * s * 0.05f)
                path.cubicTo(s * 0.2f, wv * s * 0.55f, -s * 0.05f, wv * s * 1.0f, -s * 0.4f, wv * s * 0.85f)
                path.cubicTo(-s * 0.3f, wv * s * 0.5f, -s * 0.32f, wv * s * 0.2f, -s * 0.3f, side * s * 0.05f)
                path.close()
                c.drawPath(path, paint)
            }

            // cola en abanico redondeado
            path.reset()
            path.moveTo(-s * 0.3f, s * 0.07f)
            path.quadTo(-s * 0.9f, s * 0.24f, -s * 0.8f, 0f)
            path.quadTo(-s * 0.9f, -s * 0.24f, -s * 0.3f, -s * 0.07f)
            path.close()
            c.drawPath(path, paint)

            // cuerpo y cabeza
            oval.set(-s * 0.45f, -s * 0.16f, s * 0.45f, s * 0.16f)
            c.drawOval(oval, paint)
            c.drawCircle(s * 0.44f, 0f, s * 0.12f, paint)

            c.restore()
        }
    }
}
